LE CERCLE DE L'ANXIÉTÉ — INSTALLATION WORDPRESS

1. Dans WordPress, ouvrir Extensions > Ajouter une extension > Téléverser une extension.
2. Choisir le fichier cercle-anxiete-wordpress.zip puis cliquer sur Installer maintenant.
3. Activer l'extension « Le cercle de l'anxiété ».
4. Créer ou modifier une page WordPress.
5. Ajouter un bloc « Code court » contenant exactement :

   [cercle_anxiete]

6. Pour conserver la mise en page originale, choisir si possible un modèle de page
   « Pleine largeur » ou masquer la barre latérale dans les réglages du thème.
7. Publier la page puis la tester sur ordinateur et téléphone.

DONNÉES

Les réponses, le prénom et la progression restent dans le localStorage du navigateur
du visiteur. Aucune base de données WordPress n'est utilisée et aucune réponse n'est
envoyée en ligne.

MISES À JOUR

Pour remplacer l'application plus tard, mettre à jour les fichiers du sous-dossier
app/ avec un nouveau build, puis recréer le ZIP. Ne pas modifier le code court.
