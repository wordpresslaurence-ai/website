<?php
/**
 * Plugin Name: Le cercle de l'anxiété
 * Description: Intègre l'expérience interactive « Le cercle de l'anxiété » dans une page WordPress avec le code court [cercle_anxiete].
 * Version: 1.0.0
 * Author: Marjorie Goubin
 * License: GPL-2.0-or-later
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Affiche l'application dans une iframe isolée afin de préserver exactement
 * son design et d'éviter tout conflit CSS avec le thème WordPress.
 */
function cercle_anxiete_render_shortcode()
{
    static $instance = 0;
    $instance++;

    $frame_id = 'cercle-anxiete-frame-' . $instance;
    $app_url = plugins_url('app/index.html', __FILE__);

    ob_start();
    ?>
    <div class="cercle-anxiete-wordpress">
        <iframe
            id="<?php echo esc_attr($frame_id); ?>"
            class="cercle-anxiete-wordpress__frame"
            src="<?php echo esc_url($app_url); ?>"
            title="Le cercle de l'anxiété — expérience interactive"
            loading="eager"
            scrolling="no"
        ></iframe>
    </div>
    <style>
        .cercle-anxiete-wordpress {
            width: 100%;
            max-width: none;
            margin: 0;
        }
        .cercle-anxiete-wordpress__frame {
            display: block;
            width: 100%;
            min-height: 900px;
            border: 0;
            background: #faf7ed;
        }
        @media (max-width: 680px) {
            .cercle-anxiete-wordpress__frame {
                min-height: 780px;
            }
        }
    </style>
    <script>
        (function () {
            var frame = document.getElementById(<?php echo wp_json_encode($frame_id); ?>);
            if (!frame) return;

            window.addEventListener('message', function (event) {
                if (event.source !== frame.contentWindow) return;
                if (!event.data || event.data.type !== 'cercle-anxiete:height') return;

                var height = Number(event.data.height);
                if (!Number.isFinite(height)) return;
                frame.style.height = Math.max(720, Math.min(height, 20000)) + 'px';
            });
        }());
    </script>
    <?php

    return ob_get_clean();
}

add_shortcode('cercle_anxiete', 'cercle_anxiete_render_shortcode');
