(function () {
  if (window.parent === window) return;

  var lastHeight = 0;

  function reportHeight() {
    var height = Math.max(
      document.documentElement.scrollHeight,
      document.body ? document.body.scrollHeight : 0,
    );

    if (height === lastHeight) return;
    lastHeight = height;
    window.parent.postMessage(
      { type: 'cercle-anxiete:height', height: height },
      window.location.origin,
    );
  }

  window.addEventListener('load', reportHeight);
  window.addEventListener('resize', reportHeight);

  if ('ResizeObserver' in window) {
    new ResizeObserver(reportHeight).observe(document.documentElement);
  }

  if ('MutationObserver' in window) {
    new MutationObserver(reportHeight).observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
    });
  }

  reportHeight();
}());
