(() => {
  const normalize = (value) =>
    String(value ?? '')
      .replace(/[’‘]/g, "'")
      .replace(/[“”]/g, '"')
      .replace(/[–—]/g, '-')
      .replace(/œ/g, 'oe')
      .replace(/Œ/g, 'OE')
      .replace(/…/g, '...')
      .replace(/\u00a0/g, ' ');

  const toHex = (value) => {
    let hex = '';
    for (const character of normalize(value)) {
      const code = character.codePointAt(0) ?? 63;
      const byte = code >= 32 && code <= 255 ? code : 63;
      hex += byte.toString(16).padStart(2, '0').toUpperCase();
    }
    return hex;
  };

  const wrap = (value, maxCharacters) => {
    if (!normalize(value).trim()) return [''];
    const words = normalize(value).trim().split(/\s+/);
    const lines = [];
    let current = '';
    for (const word of words) {
      const candidate = current ? `${current} ${word}` : word;
      if (candidate.length <= maxCharacters || !current) current = candidate;
      else {
        lines.push(current);
        current = word;
      }
    }
    if (current) lines.push(current);
    return lines;
  };

  const createBlob = (logicalLines) => {
    const pages = [[]];
    let page = pages[0];
    let y = 790;

    for (const logicalLine of logicalLines) {
      const size = logicalLine.size ?? 10;
      const lineHeight = size * 1.45;
      const maxCharacters = Math.max(42, Math.floor(92 * (10 / size)));
      for (const text of wrap(logicalLine.text, maxCharacters)) {
        if (y - lineHeight < 52) {
          page = [];
          pages.push(page);
          y = 790;
        }
        page.push({ ...logicalLine, text, y });
        y -= lineHeight;
      }
      y -= logicalLine.gapAfter ?? 0;
    }

    const objects = [];
    objects[1] = '<< /Type /Catalog /Pages 2 0 R >>';
    objects[3] =
      '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
    objects[4] =
      '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';
    const pageReferences = [];

    pages.forEach((lines, index) => {
      const pageId = 5 + index * 2;
      const contentId = pageId + 1;
      pageReferences.push(`${pageId} 0 R`);
      const stream = lines
        .map((line) => {
          const font = line.bold ? 'F2' : 'F1';
          const size = line.size ?? 10;
          return `BT /${font} ${size} Tf 1 0 0 1 52 ${line.y.toFixed(2)} Tm <${toHex(line.text)}> Tj ET`;
        })
        .join('\n');
      objects[pageId] =
        `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] ` +
        `/Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> ` +
        `/Contents ${contentId} 0 R >>`;
      objects[contentId] =
        `<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`;
    });

    objects[2] =
      `<< /Type /Pages /Count ${pages.length} /Kids [${pageReferences.join(' ')}] >>`;
    let pdf = '%PDF-1.4\n% Generated locally by Le cercle de l anxiete\n';
    const offsets = new Array(objects.length).fill(0);
    for (let index = 1; index < objects.length; index += 1) {
      offsets[index] = pdf.length;
      pdf += `${index} 0 obj\n${objects[index]}\nendobj\n`;
    }
    const xrefOffset = pdf.length;
    pdf += `xref\n0 ${objects.length}\n0000000000 65535 f \n`;
    for (let index = 1; index < objects.length; index += 1) {
      pdf += `${offsets[index].toString().padStart(10, '0')} 00000 n \n`;
    }
    pdf +=
      `trailer\n<< /Size ${objects.length} /Root 1 0 R >>\n` +
      `startxref\n${xrefOffset}\n%%EOF`;
    return new Blob([new TextEncoder().encode(pdf)], {
      type: 'application/pdf',
    });
  };

  window.cercleDownloadPdf = (data) => {
    const lines = [
      {
        text: 'Le cercle de l’anxiété — récapitulatif personnel',
        size: 17,
        bold: true,
        gapAfter: 12,
      },
      {
        text: `Date : ${data.date}${data.prenom ? ` · Prénom : ${data.prenom}` : ''}`,
        gapAfter: 14,
      },
      { text: 'Tes huit réponses', size: 12, bold: true, gapAfter: 5 },
      ...data.answers.map((text) => ({ text, size: 9.5, gapAfter: 5 })),
      { text: '', gapAfter: 5 },
      { text: 'Tendances observées', size: 12, bold: true, gapAfter: 4 },
      { text: data.trends },
      { text: data.dominant, gapAfter: 10 },
      {
        text: `Habitude choisie à observer : ${data.habit}`,
        bold: true,
        gapAfter: 5,
      },
      ...(data.situation
        ? [{ text: `Situation la plus fréquente : ${data.situation}` }]
        : []),
      ...(data.goal ? [{ text: `Ce que je cherche : ${data.goal}` }] : []),
      {
        text: `Mon premier petit pas : ${data.step}`,
        bold: true,
        gapAfter: 14,
      },
      {
        text:
          'Ce récapitulatif fournit des informations générales et ne constitue ni un diagnostic ni une recommandation médicale personnalisée. Il ne remplace pas une consultation ou un accompagnement professionnel.',
        size: 8.5,
      },
    ];

    const blob = createBlob(lines);
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    const safeName = normalize(data.prenom)
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-zA-Z0-9_-]+/g, '-');
    link.href = url;
    link.download = `recapitulatif-cercle-anxiete${safeName ? `-${safeName}` : ''}.pdf`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1500);
    return blob;
  };
})();
