(() => {
  const enhanceWelcome = () => {
    const artboard = document.querySelector('.welcome-artboard');
    const button = artboard?.querySelector('.welcome-test-button');
    if (!artboard || !button || button.dataset.transitionBound === 'true') return;

    button.dataset.transitionBound = 'true';
    button.addEventListener(
      'click',
      (event) => {
        if (button.dataset.transitionPass === 'true') {
          delete button.dataset.transitionPass;
          return;
        }

        event.preventDefault();
        event.stopPropagation();
        artboard.classList.add('screen-exit');
        button.disabled = true;
        button.textContent = 'Ouverture…';

        window.setTimeout(() => {
          button.disabled = false;
          button.dataset.transitionPass = 'true';
          button.click();
        }, 340);
      },
      true,
    );
  };

  const enhancePortrait = () => {
    const portrait = document.querySelector('.about .portrait');
    if (!portrait || portrait.tagName === 'PICTURE') return;

    const picture = document.createElement('picture');
    picture.className = 'portrait';

    const source = document.createElement('source');
    source.media = '(max-width: 680px)';
    source.srcset = './assets/marjorie-portrait-mobile.png';

    const image = document.createElement('img');
    image.src = './assets/marjorie-portrait.png';
    image.alt = 'Portrait de Marjorie Goubin';
    image.width = 800;
    image.height = 798;
    image.loading = 'lazy';

    picture.append(source, image);
    portrait.replaceWith(picture);
  };

  const enhanceIndicators = () => {
    const icons = ['✦', '◎'];
    document.querySelectorAll('.indicator h3').forEach((heading, index) => {
      if (heading.querySelector('.indicator-icon')) return;
      const icon = document.createElement('span');
      icon.className = 'indicator-icon';
      icon.setAttribute('aria-hidden', 'true');
      icon.textContent = icons[index] || '◌';
      heading.prepend(icon);
    });
  };

  const enhance = () => {
    document.documentElement.dataset.pdfReady =
      typeof window.cercleDownloadPdf === 'function' ? 'true' : 'false';
    enhanceWelcome();
    document.querySelector('.intro-steps')?.classList.add('screen-enter');
    enhancePortrait();
    enhanceIndicators();
  };

  const observer = new MutationObserver(enhance);
  observer.observe(document.documentElement, { childList: true, subtree: true });
  enhance();
})();
