import { mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import { extname, join, resolve } from 'node:path';

const distDirectory = resolve('dist');
const assetsDirectory = join(distDirectory, 'assets');
const serverDirectory = join(distDirectory, 'server');

const mimeTypes = {
  '.css': 'text/css; charset=utf-8',
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.webp': 'image/webp',
  '.woff2': 'font/woff2',
};

const files = [
  ['index.html', '/index.html'],
  ...(await readdir(assetsDirectory)).map((name) => [
    join('assets', name),
    `/assets/${name}`,
  ]),
];

const embeddedAssets = {};

for (const [filePath, publicPath] of files) {
  const contents = await readFile(join(distDirectory, filePath));
  embeddedAssets[publicPath] = {
    body: contents.toString('base64'),
    contentType: mimeTypes[extname(filePath)] ?? 'application/octet-stream',
  };
}

const workerSource = `const EMBEDDED_ASSETS = ${JSON.stringify(embeddedAssets)};

function decodeBase64(value) {
  const binary = atob(value);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) {
    bytes[index] = binary.charCodeAt(index);
  }
  return bytes;
}

export default {
  async fetch(request) {
    if (request.method !== 'GET' && request.method !== 'HEAD') {
      return new Response('Method not allowed', {
        status: 405,
        headers: { Allow: 'GET, HEAD' },
      });
    }

    const url = new URL(request.url);
    const requestedPath = url.pathname === '/' ? '/index.html' : url.pathname;
    const asset = EMBEDDED_ASSETS[requestedPath];

    if (!asset) {
      const acceptsHtml = request.headers.get('accept')?.includes('text/html');
      if (!acceptsHtml) {
        return new Response('Not found', { status: 404 });
      }
    }

    const responseAsset = asset ?? EMBEDDED_ASSETS['/index.html'];

    return new Response(
      request.method === 'HEAD' ? null : decodeBase64(responseAsset.body),
      {
        status: 200,
        headers: {
          'Content-Type': responseAsset.contentType,
          'Cache-Control': 'no-cache',
          'X-Content-Type-Options': 'nosniff',
        },
      },
    );
  },
};
`;

await mkdir(serverDirectory, { recursive: true });
await writeFile(join(serverDirectory, 'index.js'), workerSource, 'utf8');
