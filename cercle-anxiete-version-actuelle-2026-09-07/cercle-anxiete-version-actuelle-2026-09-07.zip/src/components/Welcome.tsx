interface Props {
  onStart: () => void;
  showResume: boolean;
  onResume: () => void;
  onRestart: () => void;
  isLeaving: boolean;
}

export function Welcome({ onStart, showResume, onResume, onRestart, isLeaving }: Props) {
  return (
    <section
      className={`welcome-artboard fade-in${isLeaving ? ' screen-exit' : ''}`}
      aria-labelledby="welcome-title"
    >
      <div className="welcome-blob welcome-blob-top" aria-hidden="true" />
      <div className="welcome-blob welcome-blob-bottom" aria-hidden="true" />

      <div className="welcome-dot-trail welcome-dot-trail-top" aria-hidden="true">
        <span />
        <span />
        <span />
        <span />
      </div>

      <div className="welcome-stage">
        <div className="welcome-hero-copy">
          <p className="eyebrow">Expérience interactive</p>
          <h1 id="welcome-title">
            <span>Le cercle</span>
            <span>de l’anxiété</span>
          </h1>
          <div className="welcome-details">
            <p className="welcome-tagline">
              Une expérience interactive en 8 situations
            </p>
            <p className="welcome-intro">
              Découvre comment certaines réactions peuvent te soulager sur le
              moment tout en maintenant la peur sur le long terme.
            </p>
            <p className="welcome-meta">
              <span>Environ 5 minutes</span>
              <span aria-hidden="true">·</span>
              <span>Aucune réponse enregistrée en ligne</span>
            </p>

            {showResume && (
              <div
                className="resume-banner"
                role="region"
                aria-label="Reprise de l’expérience"
              >
                <p>Tu avais commencé cette expérience.</p>
                <div className="resume-actions">
                  <button
                    type="button"
                    className="btn btn-sage"
                    onClick={onResume}
                  >
                    Reprendre
                  </button>
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={onRestart}
                  >
                    Recommencer
                  </button>
                </div>
              </div>
            )}

            <button
              type="button"
              className="btn welcome-test-button"
              onClick={showResume ? onRestart : onStart}
              disabled={isLeaving}
            >
              {isLeaving ? 'Ouverture…' : 'Faire le test'}
              <span aria-hidden="true">→</span>
            </button>
          </div>
        </div>

        <div className="welcome-cycle" aria-hidden="true">
          <div className="welcome-cycle-ring welcome-cycle-ring-main" />
          <div className="welcome-cycle-ring welcome-cycle-ring-echo" />
          <span className="welcome-orbit-dot welcome-orbit-dot-1" />
          <span className="welcome-orbit-dot welcome-orbit-dot-2" />
          <span className="welcome-orbit-dot welcome-orbit-dot-3" />
          <span className="welcome-orbit-dot welcome-orbit-dot-4" />
        </div>
      </div>

      <div className="welcome-leaves" aria-hidden="true">
        <span />
        <span />
        <span />
        <span />
        <span />
      </div>
    </section>
  );
}
