import type { AppState, Category } from '../types';
import { CATEGORY_META } from '../types';
import { SCENARIOS } from '../data/scenarios';
import {
  answerCategory,
  countCategories,
  dominantCategory,
  plural,
} from '../utils/scoring';
import { DOMINANT_MESSAGE } from '../data/content';

interface Props {
  state: AppState;
  onPrenomChange: (value: string) => void;
}

interface PdfLine {
  text: string;
  size?: number;
  bold?: boolean;
  gapAfter?: number;
}

interface PositionedPdfLine extends PdfLine {
  y: number;
}

const CAT_BG: Record<Category, string> = {
  evitement: '#A3543D',
  securite: '#D49A89',
};

const normalizePdfText = (value: string): string =>
  value
    .replace(/[’‘]/g, "'")
    .replace(/[“”]/g, '"')
    .replace(/[–—]/g, '-')
    .replace(/œ/g, 'oe')
    .replace(/Œ/g, 'OE')
    .replace(/…/g, '...')
    .replace(/\u00a0/g, ' ');

const toWinAnsiHex = (value: string): string => {
  let hex = '';
  for (const character of normalizePdfText(value)) {
    const code = character.codePointAt(0) ?? 63;
    const byte = code >= 32 && code <= 255 ? code : 63;
    hex += byte.toString(16).padStart(2, '0').toUpperCase();
  }
  return hex;
};

const wrapPdfText = (value: string, maxCharacters: number): string[] => {
  if (!value.trim()) return [''];

  const words = normalizePdfText(value).trim().split(/\s+/);
  const lines: string[] = [];
  let current = '';

  for (const word of words) {
    const candidate = current ? `${current} ${word}` : word;
    if (candidate.length <= maxCharacters || !current) {
      current = candidate;
    } else {
      lines.push(current);
      current = word;
    }
  }

  if (current) lines.push(current);
  return lines;
};

const createPdfBlob = (logicalLines: PdfLine[]): Blob => {
  const pages: PositionedPdfLine[][] = [[]];
  let currentPage = pages[0];
  let y = 790;
  const bottomMargin = 52;

  for (const logicalLine of logicalLines) {
    const size = logicalLine.size ?? 10;
    const lineHeight = size * 1.45;
    const maxCharacters = Math.max(42, Math.floor(92 * (10 / size)));
    const wrapped = wrapPdfText(logicalLine.text, maxCharacters);

    for (const text of wrapped) {
      if (y - lineHeight < bottomMargin) {
        currentPage = [];
        pages.push(currentPage);
        y = 790;
      }
      currentPage.push({ ...logicalLine, text, y });
      y -= lineHeight;
    }

    y -= logicalLine.gapAfter ?? 0;
  }

  const objects: string[] = [];
  objects[1] = '<< /Type /Catalog /Pages 2 0 R >>';
  objects[3] =
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
  objects[4] =
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';

  const pageReferences: string[] = [];
  pages.forEach((page, index) => {
    const pageObjectId = 5 + index * 2;
    const contentObjectId = pageObjectId + 1;
    pageReferences.push(`${pageObjectId} 0 R`);

    const stream = page
      .map((line) => {
        const font = line.bold ? 'F2' : 'F1';
        const size = line.size ?? 10;
        return `BT /${font} ${size} Tf 1 0 0 1 52 ${line.y.toFixed(2)} Tm <${toWinAnsiHex(line.text)}> Tj ET`;
      })
      .join('\n');

    objects[pageObjectId] =
      `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] ` +
      `/Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> ` +
      `/Contents ${contentObjectId} 0 R >>`;
    objects[contentObjectId] =
      `<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`;
  });

  objects[2] =
    `<< /Type /Pages /Count ${pages.length} /Kids [${pageReferences.join(' ')}] >>`;

  let pdf = '%PDF-1.4\n% Generated locally by Le cercle de l anxiete\n';
  const offsets = new Array<number>(objects.length).fill(0);

  for (let index = 1; index < objects.length; index += 1) {
    offsets[index] = pdf.length;
    pdf += `${index} 0 obj\n${objects[index]}\nendobj\n`;
  }

  const xrefOffset = pdf.length;
  pdf += `xref\n0 ${objects.length}\n`;
  pdf += '0000000000 65535 f \n';
  for (let index = 1; index < objects.length; index += 1) {
    pdf += `${offsets[index].toString().padStart(10, '0')} 00000 n \n`;
  }
  pdf +=
    `trailer\n<< /Size ${objects.length} /Root 1 0 R >>\n` +
    `startxref\n${xrefOffset}\n%%EOF`;

  return new Blob([new TextEncoder().encode(pdf)], {
    type: 'application/pdf',
  });
};

export function PrintableSummary({ state, onPrenomChange }: Props) {
  const { answers, firstStep, prenom } = state;
  const counts = countCategories(answers);
  const dominant = dominantCategory(counts);
  const dateStr = new Date().toLocaleDateString('fr-FR', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  const habitScenario = SCENARIOS.find(
    (scenario) => scenario.id === firstStep.habitScenarioId,
  );
  const habitChoiceIndex = habitScenario
    ? answers[habitScenario.index - 1]
    : null;
  const habitLabel =
    habitScenario && habitChoiceIndex !== null && habitChoiceIndex !== undefined
      ? habitScenario.choices[habitChoiceIndex].habit ?? habitScenario.title
      : habitScenario?.title ?? '—';

  const goalLabel =
    firstStep.goal === 'autre'
      ? firstStep.goalOther || 'autre'
      : firstStep.goal || '—';

  const handleDownload = () => {
    const answerLines = SCENARIOS.map((scenario, index) => {
      const choiceIndex = answers[index];
      const answer =
        choiceIndex !== null && choiceIndex !== undefined
          ? scenario.choices[choiceIndex].text
          : 'sans réponse';
      return `${index + 1}. ${scenario.title} — ${answer}`;
    });

    const pdfLines: PdfLine[] = [
      {
        text: 'Le cercle de l’anxiété — récapitulatif personnel',
        size: 17,
        bold: true,
        gapAfter: 12,
      },
      {
        text: `Date : ${dateStr}${prenom.trim() ? ` · Prénom : ${prenom.trim()}` : ''}`,
        size: 10,
        gapAfter: 14,
      },
      { text: 'Tes huit réponses', size: 12, bold: true, gapAfter: 5 },
      ...answerLines.map((text) => ({ text, size: 9.5, gapAfter: 5 })),
      { text: '', gapAfter: 5 },
      { text: 'Tendances observées', size: 12, bold: true, gapAfter: 4 },
      {
        text: `${plural(counts.evitement, 'évitement', 'évitements')} et ${plural(
          counts.securite,
          'comportement de sécurité',
          'comportements de sécurité',
        )}.`,
        size: 10,
      },
      { text: DOMINANT_MESSAGE[dominant], size: 10, gapAfter: 10 },
      {
        text: `Habitude choisie à observer : ${habitLabel}`,
        size: 10,
        bold: true,
        gapAfter: 5,
      },
      ...(firstStep.situationText.trim()
        ? [
            {
              text: `Situation la plus fréquente : ${firstStep.situationText.trim()}`,
              size: 10,
            },
          ]
        : []),
      ...(firstStep.goal
        ? [{ text: `Ce que je cherche : ${goalLabel}`, size: 10 }]
        : []),
      {
        text: `Mon premier petit pas : ${firstStep.step || '—'}`,
        size: 10,
        bold: true,
        gapAfter: 14,
      },
      {
        text:
          'Ce récapitulatif fournit des informations générales et ne constitue ni un diagnostic ni une recommandation médicale personnalisée. Il ne remplace pas une consultation ou un accompagnement professionnel.',
        size: 8.5,
      },
    ];

    const blob = createPdfBlob(pdfLines);
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    const safeName = prenom
      .trim()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-zA-Z0-9_-]+/g, '-');
    link.href = url;
    link.download = `recapitulatif-cercle-anxiete${safeName ? `-${safeName}` : ''}.pdf`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1500);
  };

  return (
    <section aria-labelledby="summary-title" className="printable-region">
      <div className="section-head no-print">
        <p className="eyebrow">À conserver</p>
        <h2 id="summary-title">Ton récapitulatif</h2>
        <p className="text-muted">
          Aucune adresse e-mail n’est demandée. Le récapitulatif reste sur ton
          appareil ; tu peux le télécharger en PDF ou l’imprimer.
        </p>
        <label className="field" style={{ maxWidth: 320 }}>
          <span>Ton prénom (facultatif)</span>
          <input
            type="text"
            value={prenom}
            onChange={(event) => onPrenomChange(event.target.value)}
            placeholder="Uniquement si tu le souhaites"
            autoComplete="given-name"
          />
        </label>
      </div>

      <div className="summary-card printable">
        <p className="print-only" style={{ fontWeight: 700 }}>
          Le cercle de l’anxiété — récapitulatif personnel
        </p>

        <div className="summary-line">
          <span className="q">Date : </span>
          {dateStr}
          {prenom.trim() && (
            <>
              {' · '}
              <span className="q">Prénom : </span>
              {prenom.trim()}
            </>
          )}
        </div>

        <div className="summary-line">
          <span className="q">Tes huit réponses</span>
          <ul className="summary-answers">
            {SCENARIOS.map((scenario, index) => {
              const category = answerCategory(answers, index);
              const choiceIndex = answers[index];
              const meta = category ? CATEGORY_META[category] : null;
              return (
                <li key={scenario.id}>
                  {meta && (
                    <span
                      className="cat"
                      style={{ background: CAT_BG[category as Category] }}
                    >
                      {meta.label}
                    </span>
                  )}
                  <strong>{scenario.title}</strong>
                  {' — '}
                  {choiceIndex !== null && choiceIndex !== undefined
                    ? scenario.choices[choiceIndex].text
                    : 'sans réponse'}
                </li>
              );
            })}
          </ul>
        </div>

        <div className="summary-line">
          <span className="q">Tendances observées : </span>
          {plural(counts.evitement, 'évitement', 'évitements')} et{' '}
          {plural(
            counts.securite,
            'comportement de sécurité',
            'comportements de sécurité',
          )}
          .
          <p style={{ margin: '0.5rem 0 0' }}>{DOMINANT_MESSAGE[dominant]}</p>
        </div>

        <div className="summary-line">
          <span className="q">Habitude choisie à observer : </span>
          {habitLabel}
        </div>

        {(firstStep.situationText.trim() || firstStep.goal) && (
          <div className="summary-line">
            {firstStep.situationText.trim() && (
              <>
                <span className="q">Situation la plus fréquente : </span>
                {firstStep.situationText.trim()}
                <br />
              </>
            )}
            {firstStep.goal && (
              <>
                <span className="q">Ce que je cherche : </span>
                {goalLabel}
              </>
            )}
          </div>
        )}

        <div className="summary-line">
          <span className="q">Mon premier petit pas : </span>
          {firstStep.step || '—'}
        </div>

        <div className="summary-line">
          <em>
            Ce récapitulatif fournit des informations générales et ne constitue
            ni un diagnostic ni une recommandation médicale personnalisée. Il ne
            remplace pas une consultation ou un accompagnement professionnel.
          </em>
        </div>
      </div>

      <div className="summary-download-actions no-print">
        <button type="button" className="btn" onClick={handleDownload}>
          Télécharger mon PDF
        </button>
        <button
          type="button"
          className="btn btn-secondary"
          onClick={() => window.print()}
        >
          Imprimer
        </button>
      </div>
    </section>
  );
}
