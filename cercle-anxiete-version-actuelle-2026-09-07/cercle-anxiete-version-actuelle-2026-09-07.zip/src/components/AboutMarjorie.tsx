export function AboutMarjorie() {
  return (
    <section className="about" aria-labelledby="about-title">
      <picture className="portrait">
        <source
          media="(max-width: 680px)"
          srcSet="./assets/marjorie-portrait-mobile.png"
        />
        <img
          src="./assets/marjorie-portrait.png"
          alt="Portrait de Marjorie Goubin"
          width="800"
          height="798"
          loading="lazy"
        />
      </picture>
      <div>
        <span className="hand" id="about-title">
          Hello
        </span>
        <p>
          Je m’appelle Marjorie et je suis thérapeute spécialisée en gestion de
          l’anxiété.
        </p>
        <p>
          Pendant plus de 20 ans, j’ai vécu avec une anxiété intense, marquée par
          des périodes de stress chronique et les séquelles d’un traumatisme.
        </p>
        <p>
          Depuis bientôt 5 ans, j’accompagne des personnes qui vivent avec des
          crises d’angoisse, des troubles anxieux et la peur d’avoir peur à
          retrouver progressivement davantage de liberté.
        </p>
      </div>
    </section>
  );
}
