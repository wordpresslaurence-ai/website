# Polices officielles de Marjorie

Déposer ici les fichiers sous ces noms dès que les licences et les fichiers sont disponibles :

- `Nourd-Regular.woff2`
- `Nourd-Bold.woff2`
- `Mistrully-Regular.woff2`
- `TTNormsPro-Bold.woff2`

Les déclarations prêtes à être activées se trouvent dans `src/styles/fonts.css`.
En attendant, le site conserve les polices de repli prévues par la charte, sans chargement externe.
